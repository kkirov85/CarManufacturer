﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpeedRacing
{
    public class Car
    {
        public Car()
        {
            Model = "Empty";
            FuelAmount = 0;
            FuelConsumptionPerKilometer = 0;
            TravelledDistance = 0;
        }
        public Car(string model, double fuelAmount, double fuelConsumption)
            :this()
        {
            Model = model;
            FuelAmount = fuelAmount;
            FuelConsumptionPerKilometer = fuelConsumption;
            TravelledDistance = 0;
        }


        public string Model { get; set; }

        public double FuelAmount { get; set; }

        public double FuelConsumptionPerKilometer { get; set; }

        public double TravelledDistance { get; set; }

        public void Drive(double amountOfKm)
        {
            //"Drive {carModel} {amountOfKm}"
            
            double getFuel = FuelAmount - (amountOfKm * FuelConsumptionPerKilometer);

            if (getFuel > 0) 
            {
                FuelAmount -= (amountOfKm * FuelConsumptionPerKilometer);
                TravelledDistance += amountOfKm;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");
            }
        }

    }
}
