﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarSalesman
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            //"{model} {power} {displacement} {efficiency}"

            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] inputEngine = Console.ReadLine().Split(' ',StringSplitOptions.RemoveEmptyEntries);

                string model = inputEngine[0];
                int power = int.Parse(inputEngine[1]);
                int displacement = 0;
                string efficiency = string.Empty;

                if (inputEngine.Length == 3)
                {
                    bool isNum = false;

                    int current;

                    string currentInput = inputEngine[2];
                    isNum = int.TryParse(currentInput, out current);

                    if (isNum)
                    {
                        displacement = int.Parse(inputEngine[2]);
                    }
                    else
                    {
                        efficiency = inputEngine[2];
                    }
                }

                if (inputEngine.Length == 4)
                {
                    displacement = int.Parse(inputEngine[2]);
                    efficiency = inputEngine[3];
                }

                Engine engine = new Engine(model, power, displacement, efficiency);

                engines.Add(engine);
            }

            int m = int.Parse(Console.ReadLine());
            //"{model} {engine} {weight} {color}"

            for (int i = 0; i < m; i++)
            {
                string[] inputCar = Console.ReadLine().Split(' ',StringSplitOptions.RemoveEmptyEntries);

                string model = inputCar[0];
                string engine = inputCar[1];

                Engine currentEngine = engines.FirstOrDefault(x => x.Model == engine);

                int weigth = 0;
                string color = string.Empty;

                if (inputCar.Length == 3)
                {
                    bool isNum = false;

                    int current;

                    string currentInput = inputCar[2];
                    isNum = int.TryParse(currentInput, out current);

                    if (isNum)
                    {
                        weigth = int.Parse(inputCar[2]);
                    }
                    else
                    {
                        color = inputCar[2];
                    }
                }

                if (inputCar.Length == 4)
                {
                    weigth = int.Parse(inputCar[2]);
                    color = inputCar[3];
                }

                Car car = new Car(model, currentEngine, weigth,color);

                cars.Add(car);
            }

            foreach (var car in cars)
            {
               

                Console.WriteLine($"{car.Model}:");
                Console.WriteLine($" {car.Engine.Model}:");
                Console.WriteLine($"   Power: {car.Engine.Power}");
                Console.WriteLine($"   Displacement: {IsExists(car.Engine.Displacement.ToString())}");
                Console.WriteLine($"   Efficiency: {IsExists(car.Engine.Efficiency)}");
                Console.WriteLine($"  Weight: {IsExists(car.Weight.ToString())}");
                Console.WriteLine($"  Color: {IsExists(car.Color)}");

            }

            
        }
        static string IsExists(string input)
        {
            string output;
            if (input == "0" || input == string.Empty)
            {                
                output = "n/a";
            }
            else
            {
                output = input;
            }

            return output;
        }
       
    }
}
