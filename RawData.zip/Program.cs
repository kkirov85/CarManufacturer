﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            //"{model} {engineSpeed} {enginePower} {cargoWeight} {cargoType} {tire1Pressure} {tire1Age} {tire2Pressure} 
            //{ tire2Age} {tire3Pressure} {tire3Age} {tire4Pressure} {tire4Age}"

            

            List<Car> cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();

                string model = input[0];

                int engineSpeed = int.Parse(input[1]);
                int enginePower = int.Parse(input[2]);

                int cargoWeight = int.Parse(input[3]);
                string cargoType = input[4];

                var tires = new Tire[4];
                int counter = 0;

                for (int y = 5; y < input.Length; y+= 2)
                {
                    double tirePressure = double.Parse(input[y]);
                    int tireAge = int.Parse(input[y + 1]);

                    var currentTyre = new Tire(tirePressure, tireAge);

                    tires[counter++] = currentTyre;
                }

                Engine engine = new Engine(engineSpeed, enginePower);
                Cargo cargo = new Cargo(cargoWeight, cargoType);


                Car currentcar = new Car(model, cargo, engine, tires);

                cars.Add(currentcar);

            }

            string command = Console.ReadLine();
            
            if (command == "fragile")
            {
                var exactCar = cars.Where(x => x.Cargo.CargoType == "fragile" && x.Tires.Any(tire => tire.Pressure < 1)).ToList();

                foreach (var car in exactCar)
                {
                    Console.WriteLine(car.Model);
                }
            }
            else
            {
               var exactCar = cars.Where(x => x.Cargo.CargoType == "flamable" && x.Engine.EnginePower > 250).ToList();

                foreach (var car in exactCar)
                {
                    Console.WriteLine(car.Model);
                }
            }

            
        }
    }
}
