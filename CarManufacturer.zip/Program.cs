﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int distance = int.Parse(Console.ReadLine());

            string input = Console.ReadLine();

            List<Tire[]> tires = new List<Tire[]>();

            while (input != "No more tires")
            {
                var tire = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                var allTires = new Tire[4]
                {
                    new Tire(int.Parse(tire[0]), double.Parse(tire[1])),
                    new Tire(int.Parse(tire[2]), double.Parse(tire[3])),
                    new Tire(int.Parse(tire[4]), double.Parse(tire[5])),
                    new Tire(int.Parse(tire[6]), double.Parse(tire[7])),
                };

                tires.Add(allTires);
                input = Console.ReadLine();
            }

            input = Console.ReadLine();
            List<Engine> engine = new List<Engine>();

            while (input != "Engines done")
            {
                var curr = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                var currEngine = new Engine(int.Parse(curr[0].ToString()), double.Parse(curr[1].ToString()));

                engine.Add(currEngine);

                input = Console.ReadLine();
            }

            List<Car> cars = new List<Car>();

            input = Console.ReadLine();

            while (input != "Show special")
            {
                var curr = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string make = curr[0].ToString();
                string model = curr[1].ToString();
                int year = int.Parse(curr[2].ToString());
                double fuelQuantity = double.Parse(curr[3].ToString());
                double fuelConsumption = double.Parse(curr[4].ToString());
                int engineIndex = int.Parse(curr[5].ToString());
                int tiresIndex = int.Parse(curr[6].ToString());


                if ((engineIndex >= 0 && engineIndex < engine.Count) && (tiresIndex >= 0 && tiresIndex < tires.Count))
                {
                    var car = new Car(make, model, year, fuelQuantity, fuelConsumption, engine[engineIndex], tires[tiresIndex]);
                    cars.Add(car);
                }

                input = Console.ReadLine();
            }

            cars = cars.Where(x => x.Year >= 2017 
                           && x.Engine.HorsePower > 330 
                           && x.Tires.Sum(y => y.Pressure) >= 9 
                           && x.Tires.Sum(y => y.Pressure) < 10).ToList();

            if (cars.Any())
            {
                foreach (var car in cars)
                {
                    car.Drive(distance);
                    Console.WriteLine(car.WhoAmI());
                }
            }
        }
    }
}
